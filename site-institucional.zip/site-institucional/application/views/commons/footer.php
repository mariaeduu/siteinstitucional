<footer class="footer">
<div class="container">
<p class="text-muted">&copy; Copyright 2016</p>
</div>
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script src="http://getbootstrap.com/assets/assets/js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>